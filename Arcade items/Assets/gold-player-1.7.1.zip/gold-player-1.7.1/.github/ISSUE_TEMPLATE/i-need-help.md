---
name: I need help
about: You need help with a certain feature and/or you don't know how to do a thing
title: ''
labels: help wanted
assignees: ''

---

**What I want to do:**
Provide a clear description of what you want to accomplish.

**What I've tried:**
Tell me what you've tried to do (if you any tried anything) so far to do the thing you want to do.

**How it could be improved:**
If you've tried and semi-succeeded, tell me if you think it could be made easier.
